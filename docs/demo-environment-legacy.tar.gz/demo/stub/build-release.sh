#!/bin/bash
# 裸机部署包构建器：交叉编译静态二进制 + 服务器脚本 + systemd unit + 证书 → tar.gz
#
# 用法：
#   ./build-release.sh                    # 证书取自 demo-certs 卷（docker cp，需 Docker Desktop 运行）
#   ./build-release.sh --certs-dir <dir>  # 证书取自本地目录（CERT_DIR 布局：upstream/server.chain.crt、
#                                         #   upstream/server.key、certificates/demo-upstream-ca/1/ca.pem）
# 产物：demo/dist/sa-gw-stub-30-<arch>.tar.gz（arch = amd64 / arm64，各一包）
#
# 目标机要求：仅 Debian Linux（纯静态二进制），无 Docker/openssl/Go 依赖。
set -euo pipefail
cd "$(dirname "$0")"

CERTS_OPT=""
if [ "${1:-}" = "--certs-dir" ] && [ -n "${2:-}" ]; then
  CERTS_OPT="$2"; shift 2 || true
fi
ARCHS="${ARCHS:-amd64 arm64}"
DIST="$(pwd)/dist"
mkdir -p "$DIST"
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT

echo "==> 交叉编译静态二进制（goproxy.cn + go.sum 校验）"
export GOPROXY="${GOPROXY:-https://goproxy.cn,direct}" GOSUMDB=off
for arch in $ARCHS; do
  GOOS=linux GOARCH=$arch CGO_ENABLED=0 go build -trimpath -ldflags "-s -w" \
    -o "$STAGE/origin-linux-$arch" ./cmd/origin
  GOOS=linux GOARCH=$arch CGO_ENABLED=0 go build -trimpath -ldflags "-s -w" \
    -o "$STAGE/stubgrpc-linux-$arch" ./cmd/stubgrpc
done

echo "==> 收集证书"
CERT_SRC="$(mktemp -d)"
if [ -n "$CERTS_OPT" ]; then
  cp -R "$CERTS_OPT"/. "$CERT_SRC"/
else
  docker cp demo-stub:/certs/upstream "$CERT_SRC/upstream"
  docker cp demo-stub:/certs/certificates "$CERT_SRC/certificates"
fi
for f in upstream/server.chain.crt upstream/server.key certificates/demo-upstream-ca/1/ca.pem; do
  [ -f "$CERT_SRC/$f" ] || { echo "缺少证书文件 $f（检查 --certs-dir 或容器状态）"; exit 1; }
done

echo "==> 组装部署包"
for arch in $ARCHS; do
  PKG="$STAGE/sa-gw-stub-30"
  mkdir -p "$PKG/bin" "$PKG/certs/upstream" "$PKG/certs/certificates/demo-upstream-ca/1" "$PKG/systemd"
  mv "$STAGE/origin-linux-$arch" "$PKG/bin/origin"
  mv "$STAGE/stubgrpc-linux-$arch" "$PKG/bin/stubgrpc"
  # 布局与编译契约一致：CERT_DIR/upstream/* + CERT_DIR/certificates/<id>/<v>/*
  cp "$CERT_SRC/upstream/server.chain.crt" "$PKG/certs/upstream/"
  cp "$CERT_SRC/upstream/server.key" "$PKG/certs/upstream/"
  cp "$CERT_SRC/certificates/demo-upstream-ca/1/ca.pem" "$PKG/certs/certificates/demo-upstream-ca/1/ca.pem"
  cp entrypoint.sh "$PKG/stub-30.sh"
  cp stub-ctl.sh "$PKG/stub-ctl.sh"
  cat > "$PKG/systemd/sa-gw-stub-30.service" <<UNIT
[Unit]
Description=sa-gateway 30-port test stub (origin-test x15 + stubgrpc x15)
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/sa-gw-stub-30
Environment=BIN_DIR=/opt/sa-gw-stub-30/bin
Environment=CERT_DIR=/opt/sa-gw-stub-30/certs
Environment=LOG_DIR=/var/log/sa-gw-stub-30
ExecStart=/bin/sh /opt/sa-gw-stub-30/stub-30.sh
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT
  cat > "$PKG/INSTALL.txt" <<INST
sa-gateway 30-port test stub -- Debian bare-metal deploy (no Docker / no openssl / binaries only)
=============================================================================
Contents: bin/origin + bin/stubgrpc (Go static build, linux-$arch),
          certs/ (gateway upstream trust chain), stub-30.sh (30-port launcher),
          systemd/sa-gw-stub-30.service

1) Install on target (root or sudo)
  tar xzf sa-gw-stub-30-linux-$arch.tar.gz -C /opt/         # -> /opt/sa-gw-stub-30/
  mkdir -p /var/log/sa-gw-stub-30
  cp /opt/sa-gw-stub-30/systemd/sa-gw-stub-30.service /etc/systemd/system/
  systemctl daemon-reload && systemctl enable --now sa-gw-stub-30
  systemctl status sa-gw-stub-30                            # active (running)
  ss -ltn | grep -E '400(5[1-9]|6[0-9]|7[0-9]|80)'          # all 30 ports LISTEN

2) Without systemd (foreground/background)
  cd /opt/sa-gw-stub-30
  BIN_DIR=./bin CERT_DIR=./certs LOG_DIR=./logs nohup sh stub-30.sh >/dev/null 2>&1 &
  # stop: pkill -f 'stub-30.sh|bin/origin|bin/stubgrpc'

3) Business endpoints (all require business auth; /healthz is auth-free)
  GET /            HTML status page (browser-renderable: auth/mTLS state + endpoint list)
  GET /info        request/forwarding info as JSON echo
  GET /json        structured sample data (orders)
  GET /echo/<val>  path param + query full echo
  GET /file        CSV sample (Content-Disposition attachment)
  GET /healthz     auth-free liveness probe (200 ok)
  credentials: basic=svcuser/svcpass  bearer=mytoken  jwt=HS256 mysecret
          apikey=X-Api-Key:myapikey  custom=X-Edge-Auth:edge1

4) Wire up with the gateway (same CA as gateway side, see certs/)
  upstream targets: <server-ip>:<port> (e.g. 10.0.0.5:40051)
  - tls/mtls/grpcs/grpcmtls upstreams: gateway must trust certs/ demo-upstream-ca
    (deployed at certificates/demo-upstream-ca/1/ca.pem under gateway release dir)
  - mtls/grpcmtls upstreams: gateway must present demo-gw-client-cert (client cert)
  - Host check: gateway route rewrite.host=svc.example.com, or send that Host directly
  - credentials: basic=svcuser/svcpass  bearer=mytoken  jwt=HS256 mysecret
            apikey=X-Api-Key:myapikey  custom=X-Edge-Auth:edge1
INST
  tar czf "$DIST/sa-gw-stub-30-linux-$arch.tar.gz" -C "$STAGE" sa-gw-stub-30
  echo "  -> dist/sa-gw-stub-30-linux-$arch.tar.gz"
done

echo "==> 完成：dist/ 下共 $(ls "$DIST" | grep -c tar.gz) 个部署包"
